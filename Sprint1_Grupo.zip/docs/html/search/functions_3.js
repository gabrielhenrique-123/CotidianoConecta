var searchData=
[
  ['retranslateui_0',['retranslateui',['../classUi__MainWindow.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow::retranslateUi()'],['../classUi__services.html#ab28d410a5e785542a8e4d91b5742d58f',1,'Ui_services::retranslateUi()']]]
];
