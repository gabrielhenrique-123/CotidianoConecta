var searchData=
[
  ['menubar_0',['menubar',['../classUi__MainWindow.html#adf43d9a67adaec750aaa956b5e082f09',1,'Ui_MainWindow::menubar'],['../classUi__services.html#aecdb6d3e720944374921da509acaaa9e',1,'Ui_services::menubar']]]
];
