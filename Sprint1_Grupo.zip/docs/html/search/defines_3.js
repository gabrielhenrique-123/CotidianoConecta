var searchData=
[
  ['unix_0',['unix',['../moc__predefs_8h.html#a4e65214f450ef6326b96b52e6dd5714b',1,'moc_predefs.h']]]
];
