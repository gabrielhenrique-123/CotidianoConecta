var searchData=
[
  ['textedit_0',['textEdit',['../classUi__MainWindow.html#a955cbbea2ef1a9929c3daf38b0a6dcd5',1,'Ui_MainWindow']]]
];
