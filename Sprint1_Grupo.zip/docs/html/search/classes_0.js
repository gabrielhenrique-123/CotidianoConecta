var searchData=
[
  ['mainwindow_0',['mainwindow',['../classMainWindow.html',1,'MainWindow'],['../classUi_1_1MainWindow.html',1,'Ui::MainWindow']]]
];
