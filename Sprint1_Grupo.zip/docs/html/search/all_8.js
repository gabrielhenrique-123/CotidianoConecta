var searchData=
[
  ['name_0',['name',['../classUser.html#a643f85779a4693855c171c396f49e515',1,'User']]],
  ['nameline_1',['nameLine',['../classUi__MainWindow.html#adb1e3318cbaee684c42f18522b035fe8',1,'Ui_MainWindow']]],
  ['number_2',['number',['../classUser.html#aa3bb305559c3513a928347ce30a4a716',1,'User']]]
];
