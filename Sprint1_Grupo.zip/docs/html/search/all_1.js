var searchData=
[
  ['birth_0',['birth',['../classUser.html#aa072cfd5db1440f1c25579c75547e0ff',1,'User']]],
  ['birthline_1',['birthLine',['../classUi__MainWindow.html#ab3dae72f8e338187089bed14441c0835',1,'Ui_MainWindow']]]
];
