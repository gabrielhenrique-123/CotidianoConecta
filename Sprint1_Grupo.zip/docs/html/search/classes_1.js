var searchData=
[
  ['qt_5fmeta_5fstringdata_5fclassmainwindowendclass_5ft_0',['qt_meta_stringdata_CLASSMainWindowENDCLASS_t',['../structQT__WARNING__DISABLE__DEPRECATED_1_1qt__meta__stringdata__CLASSMainWindowENDCLASS__t.html',1,'QT_WARNING_DISABLE_DEPRECATED']]],
  ['qt_5fmeta_5fstringdata_5fclassservicesendclass_5ft_1',['qt_meta_stringdata_CLASSServicesENDCLASS_t',['../structQT__WARNING__DISABLE__DEPRECATED_1_1qt__meta__stringdata__CLASSServicesENDCLASS__t.html',1,'QT_WARNING_DISABLE_DEPRECATED']]]
];
