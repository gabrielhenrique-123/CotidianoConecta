var searchData=
[
  ['operator_3d_0',['operator=',['../classUser.html#a2b3a3b191b8f02c7bbb32f9bffca2436',1,'User']]],
  ['operator_3d_3d_1',['operator==',['../classUser.html#a2b151d814ff24f339c4e2c22af601ea7',1,'User']]]
];
