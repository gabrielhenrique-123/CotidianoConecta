var searchData=
[
  ['feedback_0',['feedback',['../classUi__MainWindow.html#a4b76aa513b1f1399824227a740251f07',1,'Ui_MainWindow']]],
  ['finish_1',['finish',['../classUi__MainWindow.html#a895cb2cb078a4113a7495d7478263e4d',1,'Ui_MainWindow']]],
  ['frame_2',['frame',['../classUi__MainWindow.html#ad01968740c435709a8b2ec4c08094c67',1,'Ui_MainWindow']]],
  ['funcao_3',['funcao',['../classUser.html#a0a655bf1ec4cdb63c0c4d5932caefd26',1,'User']]]
];
