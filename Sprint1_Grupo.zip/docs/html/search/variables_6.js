var searchData=
[
  ['offsetsandsizes_0',['offsetsandsizes',['../structQT__WARNING__DISABLE__DEPRECATED_1_1qt__meta__stringdata__CLASSMainWindowENDCLASS__t.html#af2ce05b672454230de0880fcf49fdaa6',1,'QT_WARNING_DISABLE_DEPRECATED::qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes'],['../structQT__WARNING__DISABLE__DEPRECATED_1_1qt__meta__stringdata__CLASSServicesENDCLASS__t.html#a33b5877c480ff4bcb63edb0dc579a84f',1,'QT_WARNING_DISABLE_DEPRECATED::qt_meta_stringdata_CLASSServicesENDCLASS_t::offsetsAndSizes']]]
];
