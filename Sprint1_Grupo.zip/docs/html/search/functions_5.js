var searchData=
[
  ['user_0',['user',['../classUser.html#a4a0137053e591fbb79d9057dd7d2283d',1,'User::User()'],['../classUser.html#a3997d90fbcfabdea257ff49940ea60c7',1,'User::User(string name, string cpf, string birth, string email)'],['../classUser.html#a78184063f5f8320a84dcbb18dcbeaceb',1,'User::User(const User &amp;)']]]
];
