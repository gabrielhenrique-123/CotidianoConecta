var searchData=
[
  ['getbirth_0',['getBirth',['../classUser.html#aedd5259fa518794bf14c207c5e8b2fdd',1,'User']]],
  ['getcpf_1',['getCPF',['../classUser.html#a3116f686ba64ce144cb8d5dae05ad3f3',1,'User']]],
  ['getemail_2',['getEmail',['../classUser.html#a4c647e583bd964f40f687776a0d185dc',1,'User']]],
  ['getfuncao_3',['getFuncao',['../classUser.html#a54894ddc5dc8e571fcd167b130969e11',1,'User']]],
  ['getname_4',['getName',['../classUser.html#ab9b2b5feb6bdd1582696eb6d44cee384',1,'User']]],
  ['getnumber_5',['getNumber',['../classUser.html#a9b0498ae834a440a8ec359703ce68f71',1,'User']]]
];
