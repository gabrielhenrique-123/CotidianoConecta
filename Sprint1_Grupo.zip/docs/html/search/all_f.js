var searchData=
[
  ['_7emainwindow_0',['~MainWindow',['../classMainWindow.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]],
  ['_7eservices_1',['~Services',['../classServices.html#a2ba7a245ac5bf255914e96970dff5ade',1,'Services']]],
  ['_7euser_2',['~User',['../classUser.html#ac00b72ad64eb4149f7b21b9f5468c2b2',1,'User']]]
];
