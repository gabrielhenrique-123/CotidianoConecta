#ifndef SERVICES_H
#define SERVICES_H

#include <QMainWindow>

namespace Ui {
class Services;
}

class Services : public QMainWindow
{
    Q_OBJECT

public:
    explicit Services(QWidget *parent = nullptr);
    ~Services();

private:
    Ui::Services *ui;
};

#endif // SERVICES_H
