#include "services.h"
#include "ui_services.h"

Services::Services(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Services)
{
    ui->setupUi(this);
}

Services::~Services()
{
    delete ui;
}
