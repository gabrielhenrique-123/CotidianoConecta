#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
    class MainWindow;
}
QT_END_NAMESPACE

/**
 * @brief Classe MainWindow que representa a janela principal da aplicação.
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief Construtor da classe MainWindow.
     * @param parent Ponteiro para o widget pai.
     */
    MainWindow(QWidget *parent = nullptr);

    /**
     * @brief Destrutor da classe MainWindow.
     */
    ~MainWindow();

private slots:
    /**
     * @brief Slot chamado quando o botão "finish" é clicado.
     * Realiza ações relacionadas ao término de alguma operação.
     */
    void on_finish_clicked();

private:
    Ui::MainWindow *ui; /**< Ponteiro para a interface gráfica da janela principal. */
};

#endif // MAINWINDOW_H
