#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "../usuario.hpp"

/**
 * @brief Construtor da classe MainWindow.
 * @param parent Ponteiro para o widget pai.
 */
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
}

/**
 * @brief Destrutor da classe MainWindow.
 */
MainWindow::~MainWindow() {
    delete ui;
}

/**
 * @brief Slot chamado quando o botão "finish" é clicado.
 * Cria um novo objeto User com os dados inseridos nos campos de texto,
 * salva esses dados em um arquivo e exibe uma mensagem de sucesso.
 */
void MainWindow::on_finish_clicked() {
    // Cria um novo usuário com os dados dos campos de texto
    User* usuario = new User(ui->nameLine->text().toStdString(), ui->cpfLine->text().toStdString(), ui->birthLine->text().toStdString(), ui->emailLine->text().toStdString());
    
    // Salva as informações do usuário em um arquivo
    usuario->saveToFile("dataBank.txt");

    // Exibe uma mensagem de sucesso na interface do usuário
    ui->feedback->setText("Success");
}
